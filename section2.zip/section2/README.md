# Learn Real World AngularJS Step By Step by CodeCraft
http://codecraftpro.com

## Section 2 - Creating a list application with searching and sorting

# Folders
./libs/ - The required libraries for all lectures in this course.
lesson1 - Starter template for lecture 1
lesson2 - Starter template for lecture 2
lesson3 - Starter template for lecture 3
lesson4 - Starter template for lecture 4
lesson5 - Starter template for lecture 5
lesson6 - Starter template for lecture 6
lesson7 - Starter template for lecture 7
completed - The completed application for this section